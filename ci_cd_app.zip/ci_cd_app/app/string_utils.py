def capitalize_words(text):
    return " ".join([word.capitalize() for word in text.split()])

def reverse_text(text):
    return text[::-1]
